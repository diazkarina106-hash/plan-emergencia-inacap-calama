const { getStore } = require("@netlify/blobs");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  let payload = {};
  try { payload = JSON.parse(event.body || "{}"); } catch (e) {}

  const configured = process.env.ALERT_ADMIN_PASSWORD || "Inacal";
  if (!payload.password || payload.password !== configured) {
    return {
      statusCode: 401,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Contraseña incorrecta." }),
    };
  }

  const data = {
    active: !!payload.active,
    title: String(payload.title || ""),
    message: String(payload.message || ""),
    updated_at: new Date().toISOString(),
  };

  try {
    const store = getStore("pe-alerts");
    await store.set("current", JSON.stringify(data));
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
      body: JSON.stringify({ ok: true, ...data }),
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "No se pudo guardar la alerta." }),
    };
  }
};
