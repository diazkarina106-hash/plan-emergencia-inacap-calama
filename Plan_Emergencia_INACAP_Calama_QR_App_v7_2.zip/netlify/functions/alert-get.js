const { getStore } = require("@netlify/blobs");

exports.handler = async () => {
  try {
    const store = getStore("pe-alerts");
    const raw = await store.get("current");
    const data = raw ? JSON.parse(raw) : { active:false, title:"", message:"", updated_at: null };
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
      body: JSON.stringify(data),
    };
  } catch (e) {
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
      body: JSON.stringify({ active:false, title:"", message:"", updated_at: null }),
    };
  }
};
